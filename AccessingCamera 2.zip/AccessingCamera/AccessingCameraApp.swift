//
//  AccessingCameraApp.swift
//  AccessingCamera
//
//  Created by scholar on 6/1/23.
//

import SwiftUI

@main
struct AccessingCameraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
